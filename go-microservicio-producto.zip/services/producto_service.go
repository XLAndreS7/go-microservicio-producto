package services

import (
    "go-microservicio-producto/models"
    "go-microservicio-producto/repository"
)

type ProductoService struct {
    repo *repository.ProductoRepository
}

func NewProductoService(repo *repository.ProductoRepository) *ProductoService {
    return &ProductoService{
        repo: repo,
    }
}

func (s *ProductoService) CrearProducto(producto models.Producto) error {
    _, err := s.repo.Crear(producto)
    return err
}

func (s *ProductoService) ObtenerProductos() ([]models.Producto, error) {
    return s.repo.ObtenerTodos()
}

