package controllers

import (
    "encoding/json"
    "go-microservicio-producto/models"
    "go-microservicio-producto/services"
    "net/http"
)

type ProductoController struct {
    service *services.ProductoService
}

func NewProductoController(service *services.ProductoService) *ProductoController {
    return &ProductoController{
        service: service,
    }
}

// CrearProducto maneja la solicitud POST para crear un producto
func (c *ProductoController) CrearProducto(w http.ResponseWriter, r *http.Request) {
    var producto models.Producto
    err := json.NewDecoder(r.Body).Decode(&producto)
    if err != nil {
        http.Error(w, "Error al decodificar el producto", http.StatusBadRequest)
        return
    }

    err = c.service.CrearProducto(producto)
    if err != nil {
        http.Error(w, "Error al crear el producto", http.StatusInternalServerError)
        return
    }

    w.WriteHeader(http.StatusCreated)
    json.NewEncoder(w).Encode(map[string]string{"mensaje": "Producto creado correctamente"})
}

// ObtenerProductos maneja la solicitud GET para listar productos
func (c *ProductoController) ObtenerProductos(w http.ResponseWriter, r *http.Request) {
    productos, err := c.service.ObtenerProductos()
    if err != nil {
        http.Error(w, "Error al obtener productos", http.StatusInternalServerError)
        return
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(productos)
}

