package main

import (
    "context"
    "fmt"
    "go-microservicio-producto/controllers"
    "go-microservicio-producto/repository"
    "go-microservicio-producto/services"
    "log"
    "net/http"
    "os"
    "time"

    "github.com/joho/godotenv"
    "go.mongodb.org/mongo-driver/mongo"
    "go.mongodb.org/mongo-driver/mongo/options"
)

func main() {
    // Cargar archivo .env
    err := godotenv.Load()
    if err != nil {
        log.Println("Advertencia: No se pudo cargar el archivo .env, se usará configuración por defecto")
    }

    port := os.Getenv("PORT")
    if port == "" {
        port = "8080" // Valor por defecto
    }

    mongoURI := os.Getenv("MONGO_URI")
    if mongoURI == "" {
        mongoURI = "mongodb://localhost:27017"
    }

    dbName := os.Getenv("DB_NAME")
    if dbName == "" {
        dbName = "productosdb"
    }

    // Conexión a MongoDB
    client, err := mongo.NewClient(options.Client().ApplyURI(mongoURI))
    if err != nil {
        log.Fatal("Error creando cliente de MongoDB:", err)
    }

    ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
    defer cancel()

    err = client.Connect(ctx)
    if err != nil {
        log.Fatal("Error conectando a MongoDB:", err)
    }

    db := client.Database(dbName)

    // Inyección de dependencias
    productoRepo := repository.NewProductoRepository(db)
    productoService := services.NewProductoService(productoRepo)
    productoController := controllers.NewProductoController(productoService)

    // Rutas
    http.HandleFunc("/productos", func(w http.ResponseWriter, r *http.Request) {
        if r.Method == http.MethodPost {
            productoController.CrearProducto(w, r)
        } else if r.Method == http.MethodGet {
            productoController.ObtenerProductos(w, r)
        } else {
            http.Error(w, "Método no permitido", http.StatusMethodNotAllowed)
        }
    })

    // Servidor
    fmt.Printf("Servidor corriendo en http://localhost:%s\n", port)
    log.Fatal(http.ListenAndServe(":"+port, nil))
}

