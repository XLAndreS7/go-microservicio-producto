package repository

import (
    "context"
    "go-microservicio-producto/models"
    "log"
    "time"

    "go.mongodb.org/mongo-driver/bson"
    "go.mongodb.org/mongo-driver/mongo"
   // "go.mongodb.org/mongo-driver/mongo/options"
)

type ProductoRepository struct {
    collection *mongo.Collection
}

func NewProductoRepository(db *mongo.Database) *ProductoRepository {
    return &ProductoRepository{
        collection: db.Collection("productos"),
    }
}

func (r *ProductoRepository) Crear(producto models.Producto) (*mongo.InsertOneResult, error) {
    ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
    defer cancel()
    return r.collection.InsertOne(ctx, producto)
}

func (r *ProductoRepository) ObtenerTodos() ([]models.Producto, error) {
    var productos []models.Producto
    ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
    defer cancel()

    cursor, err := r.collection.Find(ctx, bson.M{})
    if err != nil {
        return nil, err
    }
    defer cursor.Close(ctx)

    for cursor.Next(ctx) {
        var producto models.Producto
        if err := cursor.Decode(&producto); err != nil {
            log.Println("Error al decodificar producto:", err)
            continue
        }
        productos = append(productos, producto)
    }

    return productos, nil
}

